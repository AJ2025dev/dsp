# AudienceStreet Campaign Hub (Ready-to-Push Repo)

This repository contains a working scaffold for:
- **Backend**: FastAPI (Equativ PMP/Inventory stubs, Pricing with Agency+Admin margins, AI Creative generation using OpenAI or MiniMax), `/health` endpoint.
- **Frontend**: React + Vite + TypeScript + Tailwind-ready sidebar with role-aware tabs; pages for PMP Deals, Media Planning, Campaigns.
- **GitHub Actions**: Auto Deploy & QA workflow that triggers Render + Vercel deploy hooks, waits for backend health, then runs your Agent Pipeline / QA.

## 1) What you need to set (one time)

### GitHub → Settings → Secrets and variables → Actions → **Secrets**
- `OPENAI_API_KEY`
- `EQUATIV_API_KEY`
- `MINIMAX_API_KEY`
- *(if needed)* `MINIMAX_GROUP_ID`
- *(optional defaults)* `DEFAULT_AGENCY_MARGIN_PCT` (e.g. `15`), `DEFAULT_ADMIN_BUFFER_PCT` (e.g. `5`)
- **Deploy hooks**
  - `RENDER_DEPLOY_HOOK` – from Render backend service → Settings → Deploy Hooks → Create
  - `VERCEL_DEPLOY_HOOK` – from Vercel project → Settings → Git → Deploy Hooks → Create

### GitHub → Settings → Secrets and variables → Actions → **Variables**
- `API_BASE_URL` = your backend URL (e.g., `https://campaign-hub-api.onrender.com`)

## 2) Deploy (suggested)
- **Backend**: Render → New Web Service → connect this repo → root = `backend` → start: `uvicorn app:app --host 0.0.0.0 --port 10000` → set env (keys above) → Deploy
- **Frontend**: Vercel → New Project → root = `frontend` → env: `VITE_API_BASE=https://YOUR_BACKEND_URL` → Deploy

## 3) Run the workflow
Push to `main` or run **Actions → Auto Deploy & QA**.

## 4) Local dev (optional)
```bash
# Backend
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
export DATABASE_URL=sqlite:///./dev.db
uvicorn app:app --reload

# Frontend
cd ../frontend
npm i
VITE_API_BASE=http://localhost:8000 npm run dev
```
Visit: http://localhost:5173

---

### Notes
- Sidebar tabs are role-aware in code; swap `role` in `src/main.tsx` (`admin` | `agency` | `advertiser`) until auth is wired.
- Equativ endpoints are **stubs**; add OAuth/token flow if your account requires it.
- AI Creatives uses OpenAI by default; MiniMax is supported if `MINIMAX_API_KEY` is present.
