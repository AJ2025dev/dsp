import React from "react"
import ReactDOM from "react-dom/client"
import { createBrowserRouter, RouterProvider } from "react-router-dom"
import AppLayout from "./layouts/AppLayout"
import type { UserRole } from "./components/Sidebar"

// Pages
import PmpDealsPage from "./pages/PmpDealsPage"
import MediaPlanningPage from "./pages/MediaPlanningPage"
import CampaignsPage from "./pages/CampaignsPage"
import CreateCampaignPage from "./pages/CreateCampaignPage"

const role: UserRole = "agency" // "admin" | "agency" | "advertiser"

const router = createBrowserRouter([
  {
    element: <AppLayout role={role} />,
    children: [
      { path: "/dashboard", element: <div>Dashboard</div> },
      { path: "/planning", element: <MediaPlanningPage /> },
      { path: "/advertisers", element: <div>Advertisers</div> },
      { path: "/campaigns", element: <CampaignsPage /> },
      { path: "/campaigns/new", element: <CreateCampaignPage /> },
      { path: "/budget", element: <div>Budget Control</div> },
      { path: "/creatives", element: <div>Creatives (use AI from backend)</div> },
      { path: "/audiences", element: <div>Audiences</div> },
      { path: "/pmp-deals", element: <PmpDealsPage /> },
      { path: "/integrations/meta", element: <div>Meta Ads</div> },
      { path: "/integrations/google", element: <div>Google Ads</div> },
      { path: "/retail-media", element: <div>Retail Media</div> },
      { path: "/reports", element: <div>Reports</div> },
      { path: "/settings", element: <div>Settings</div> },
      { path: "*", element: <div>Not Found</div> },
    ],
  },
])

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
)
