import React from "react";
import { fetchInventory } from "../api/pmp";
import { pricePreview } from "../api/campaigns";

export default function MediaPlanningPage() {
  const [accountId, setAccountId] = React.useState("");
  const [rows, setRows] = React.useState<any[]>([]);
  const [base, setBase] = React.useState<number>(1000);
  const [agencyPct, setAgencyPct] = React.useState<number>(15);
  const [adminPct, setAdminPct] = React.useState<number>(5);
  const [preview, setPreview] = React.useState<any>(null);

  async function load() {
    const inv = await fetchInventory(accountId);
    setRows(inv);
  }
  async function calc() {
    const r = await pricePreview(base, agencyPct, adminPct);
    setPreview(r);
  }

  return (
    <div className="max-w-6xl">
      <h1 className="text-2xl font-semibold mb-4">Media Planning</h1>
      <div className="grid grid-cols-2 gap-6">
        <div>
          <div className="flex gap-2 mb-3">
            <input className="border px-3 py-2 rounded" placeholder="Equativ Account ID" value={accountId} onChange={e=>setAccountId(e.target.value)} />
            <button className="px-3 py-2 rounded bg-violet-600 text-white" onClick={load}>Load Inventory</button>
          </div>
          <pre className="bg-slate-100 p-3 rounded overflow-auto max-h-80">{JSON.stringify(rows.slice(0,10), null, 2)}</pre>
        </div>
        <div>
          <div className="space-y-2">
            <div className="flex items-center gap-3"><label className="w-48">Base Price</label><input type="number" className="border px-3 py-2 rounded w-40" value={base} onChange={e=>setBase(parseFloat(e.target.value))} /></div>
            <div className="flex items-center gap-3"><label className="w-48">Agency Margin %</label><input type="number" className="border px-3 py-2 rounded w-40" value={agencyPct} onChange={e=>setAgencyPct(parseFloat(e.target.value))} /></div>
            <div className="flex items-center gap-3"><label className="w-48">Admin Buffer %</label><input type="number" className="border px-3 py-2 rounded w-40" value={adminPct} onChange={e=>setAdminPct(parseFloat(e.target.value))} /></div>
            <button className="px-3 py-2 rounded bg-violet-600 text-white" onClick={calc}>Preview Final Price</button>
          </div>
          <pre className="bg-slate-100 p-3 rounded overflow-auto mt-3">{JSON.stringify(preview, null, 2)}</pre>
        </div>
      </div>
    </div>
  );
}
