import React from "react";
export default function CampaignsPage(){
  return <div className="max-w-6xl"><h1 className="text-2xl font-semibold mb-4">Campaigns</h1><p>List + CRUD placeholder</p></div>;
}
