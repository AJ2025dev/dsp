import React from "react";
export default function CreateCampaignPage(){
  return <div className="max-w-3xl"><h1 className="text-2xl font-semibold mb-4">Create Campaign</h1><p>Form placeholder</p></div>;
}
