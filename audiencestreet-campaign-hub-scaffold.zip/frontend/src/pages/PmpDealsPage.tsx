import React from "react";
import { fetchDeals, fetchInventory } from "../api/pmp";

export default function PmpDealsPage() {
  const [accountId, setAccountId] = React.useState("");
  const [deals, setDeals] = React.useState<any[]>([]);
  const [inventory, setInventory] = React.useState<any[]>([]);

  async function load() {
    const d = await fetchDeals(accountId);
    setDeals(d);
    const inv = await fetchInventory(accountId);
    setInventory(inv);
  }

  return (
    <div className="max-w-6xl">
      <h1 className="text-2xl font-semibold mb-4">PMP Deals (Equativ)</h1>
      <div className="flex gap-2 mb-4">
        <input className="border px-3 py-2 rounded" placeholder="Equativ Account ID" value={accountId} onChange={e=>setAccountId(e.target.value)} />
        <button className="px-3 py-2 rounded bg-violet-600 text-white" onClick={load}>Load</button>
      </div>
      <h2 className="font-medium mt-4 mb-2">Deals</h2>
      <pre className="bg-slate-100 p-3 rounded overflow-auto max-h-64">{JSON.stringify(deals, null, 2)}</pre>
      <h2 className="font-medium mt-6 mb-2">Inventory</h2>
      <pre className="bg-slate-100 p-3 rounded overflow-auto max-h-64">{JSON.stringify(inventory, null, 2)}</pre>
    </div>
  );
}
