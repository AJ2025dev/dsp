import React from "react";
import { NavLink } from "react-router-dom";
import {
  LayoutDashboard,
  LineChart,
  Megaphone,
  PlusCircle,
  BadgeDollarSign,
  Image as ImageIcon,
  Users,
  Handshake,
  Globe,
  Search as SearchIcon,
  Store,
  BarChart3,
  Settings as SettingsIcon,
  CircleDot
} from "lucide-react";

export type UserRole = "admin" | "agency" | "advertiser";

export const routes = [
  { key: "dashboard",   label: "Dashboard",       icon: LayoutDashboard, path: "/dashboard",               roles: ["admin","agency","advertiser"] as UserRole[] },
  { key: "planning",    label: "Media Planning",  icon: LineChart,       path: "/planning",                roles: ["admin","agency","advertiser"] },
  { key: "advertisers", label: "Advertisers",     icon: CircleDot,       path: "/advertisers",             roles: ["admin","agency"] },
  { key: "campaigns",   label: "Campaigns",       icon: Megaphone,       path: "/campaigns",               roles: ["admin","agency","advertiser"] },
  { key: "create",      label: "Create Campaign", icon: PlusCircle,      path: "/campaigns/new",           roles: ["admin","agency","advertiser"] },
  { key: "budget",      label: "Budget Control",  icon: BadgeDollarSign, path: "/budget",                  roles: ["admin","agency","advertiser"] },
  { key: "creatives",   label: "Creatives",       icon: ImageIcon,       path: "/creatives",               roles: ["admin","agency","advertiser"] },
  { key: "audiences",   label: "Audiences",       icon: Users,           path: "/audiences",               roles: ["admin","agency","advertiser"] },
  { key: "pmp",         label: "PMP Deals",       icon: Handshake,       path: "/pmp-deals",               roles: ["admin","agency","advertiser"] },
  { key: "meta",        label: "Meta Ads",        icon: Globe,           path: "/integrations/meta",       roles: ["admin","agency","advertiser"] },
  { key: "google",      label: "Google Ads",      icon: SearchIcon,      path: "/integrations/google",     roles: ["admin","agency","advertiser"] },
  { key: "retail",      label: "Retail Media",    icon: Store,           path: "/retail-media",            roles: ["admin","agency","advertiser"] },
  { key: "reports",     label: "Reports",         icon: BarChart3,       path: "/reports",                 roles: ["admin","agency","advertiser"] },
  { key: "settings",    label: "Settings",        icon: SettingsIcon,    path: "/settings",                roles: ["admin","agency","advertiser"] },
];

function cx(...cls: (string | false | null | undefined)[]) { return cls.filter(Boolean).join(" "); }

export default function Sidebar({ role }: { role: UserRole }) {
  const items = routes.filter(r => r.roles.includes(role));
  return (
    <aside className="w-64 shrink-0 border-r bg-white/60">
      <div className="px-4 py-5">
        <div className="text-xs font-semibold text-slate-500 tracking-wider mb-3">NAVIGATION</div>
        <nav className="flex flex-col gap-1">
          {items.map(({ key, label, icon: Icon, path }) => (
            <NavLink
              key={key}
              to={path}
              className={({ isActive }) =>
                cx(
                  "group flex items-center gap-3 rounded-xl px-3 py-2 text-sm font-medium",
                  isActive ? "bg-violet-600 text-white shadow" : "text-slate-700 hover:bg-slate-100"
                )
              }
            >
              <Icon className="h-4 w-4 opacity-90" />
              <span>{label}</span>
            </NavLink>
          ))}
        </nav>
      </div>
    </aside>
  );
}
