import { api } from "./client";
export async function pricePreview(base: number, agencyPct?: number, adminPct?: number) {
  const p = new URLSearchParams({ base: String(base) });
  if (agencyPct !== undefined) p.set("agency_pct", String(agencyPct));
  if (adminPct  !== undefined) p.set("admin_pct",  String(adminPct));
  return api(`/api/campaigns/price?${p.toString()}`);
}
