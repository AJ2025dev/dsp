import { api } from "./client";
export async function fetchDeals(accountId: string) {
  return api(`/api/pmp/deals?account_id=${encodeURIComponent(accountId)}`);
}
export async function fetchInventory(accountId: string, q?: string) {
  const qs = q ? `&q=${encodeURIComponent(q)}` : "";
  return api(`/api/pmp/inventory?account_id=${encodeURIComponent(accountId)}${qs}`);
}
