import { api } from "./client";
export async function genTextCreatives(product: string, audience: string, provider: "openai" | "minimax" = "openai") {
  return api(`/api/creatives/text`, {
    method: "POST",
    body: JSON.stringify({ product, audience, provider })
  });
}
