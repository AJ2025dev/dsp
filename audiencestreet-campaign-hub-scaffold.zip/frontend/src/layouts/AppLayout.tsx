import React from "react";
import Sidebar, { UserRole } from "../components/Sidebar";
import { Outlet } from "react-router-dom";

export default function AppLayout({ role }: { role: UserRole }) {
  return (
    <div className="min-h-screen w-full bg-slate-50 text-slate-900 flex">
      <Sidebar role={role} />
      <main className="flex-1 p-6">
        <Outlet />
      </main>
    </div>
  );
}
