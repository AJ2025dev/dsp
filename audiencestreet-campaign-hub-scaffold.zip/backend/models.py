from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, Date, Numeric
from sqlalchemy.orm import relationship
from db import Base

class Tenant(Base):
    __tablename__ = "tenants"
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)

class Brand(Base):
    __tablename__ = "brands"
    id = Column(Integer, primary_key=True)
    tenant_id = Column(Integer, ForeignKey("tenants.id"), nullable=False)
    name = Column(String, nullable=False)

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    email = Column(String, unique=True, nullable=False)
    password_hash = Column(String, nullable=False)
    is_active = Column(Boolean, default=True)

class Membership(Base):
    __tablename__ = "memberships"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    tenant_id = Column(Integer, ForeignKey("tenants.id"))
    brand_id = Column(Integer, ForeignKey("brands.id"))
    role = Column(String, nullable=False)

class InventoryItem(Base):
    __tablename__ = "inventory_items"
    id = Column(Integer, primary_key=True)
    tenant_id = Column(Integer, ForeignKey("tenants.id"), nullable=False)
    name = Column(String, nullable=False)
    format = Column(String)
    platform = Column(String)
    price = Column(Numeric)
    availability = Column(String)

class Campaign(Base):
    __tablename__ = "campaigns"
    id = Column(Integer, primary_key=True)
    brand_id = Column(Integer, ForeignKey("brands.id"), nullable=False)
    name = Column(String, nullable=False)
    budget = Column(Numeric, default=0)
    start_date = Column(Date)
    end_date = Column(Date)
    status = Column(String, default="draft")

class Placement(Base):
    __tablename__ = "placements"
    id = Column(Integer, primary_key=True)
    campaign_id = Column(Integer, ForeignKey("campaigns.id"), nullable=False)
    inventory_item_id = Column(Integer, ForeignKey("inventory_items.id"))
    description = Column(String)
    base_price = Column(Numeric, default=0)
    agency_margin_pct = Column(Numeric, default=0)
    admin_buffer_pct = Column(Numeric, default=0)
    final_price = Column(Numeric, default=0)
