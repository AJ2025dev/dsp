from fastapi import APIRouter
import os

router = APIRouter()

@router.get("/settings/margins")
def get_default_margins():
    return {
        "DEFAULT_AGENCY_MARGIN_PCT": os.getenv("DEFAULT_AGENCY_MARGIN_PCT", "15"),
        "DEFAULT_ADMIN_BUFFER_PCT": os.getenv("DEFAULT_ADMIN_BUFFER_PCT", "5"),
    }
