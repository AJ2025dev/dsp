from fastapi import APIRouter

router = APIRouter()

@router.get("/meta/status")
def meta_status():
    return {"ok": True, "message": "Meta Ads integration placeholder"}

@router.get("/google/status")
def google_status():
    return {"ok": True, "message": "Google Ads integration placeholder"}

@router.get("/retail/status")
def retail_status():
    return {"ok": True, "message": "Retail media integration placeholder"}
