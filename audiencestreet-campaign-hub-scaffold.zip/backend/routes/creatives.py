from fastapi import APIRouter, Body
from services.creatives_ai import gen_text_openai, gen_text_minimax

router = APIRouter()

@router.post("/text")
def generate_text(
    product: str = Body(...),
    audience: str = Body(...),
    provider: str = Body("openai")
):
    if provider == "minimax":
        return gen_text_minimax(product, audience)
    return gen_text_openai(product, audience)
