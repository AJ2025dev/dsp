from fastapi import APIRouter, HTTPException
import os, decimal

router = APIRouter()

DEFAULT_AGENCY_MARGIN = decimal.Decimal(os.getenv("DEFAULT_AGENCY_MARGIN_PCT", "15"))
DEFAULT_ADMIN_BUFFER = decimal.Decimal(os.getenv("DEFAULT_ADMIN_BUFFER_PCT", "5"))

def price_with_margins(base: decimal.Decimal, agency_pct: decimal.Decimal | None, admin_pct: decimal.Decimal | None) -> str:
    a = (agency_pct if agency_pct is not None else DEFAULT_AGENCY_MARGIN) / decimal.Decimal(100)
    b = (admin_pct  if admin_pct  is not None else DEFAULT_ADMIN_BUFFER) / decimal.Decimal(100)
    final = base * (1 + a) * (1 + b)
    return str(final.quantize(decimal.Decimal("0.01")))

@router.get("/price")
def compute_price(base: float, agency_pct: float | None = None, admin_pct: float | None = None):
    try:
        base_d = decimal.Decimal(str(base))
        ag = decimal.Decimal(str(agency_pct)) if agency_pct is not None else None
        ad = decimal.Decimal(str(admin_pct))  if admin_pct  is not None else None
        return {"base": base, "final": price_with_margins(base_d, ag, ad)}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
