from fastapi import APIRouter, HTTPException
from services import equativ

router = APIRouter()

@router.get("/deals")
def get_pmp_deals(account_id: str):
    try:
        return equativ.list_pmp_deals(account_id)
    except Exception as e:
        raise HTTPException(status_code=502, detail=str(e))

@router.get("/inventory")
def get_inventory(account_id: str, q: str | None = None):
    try:
        query = None
        if q:
            query = dict(pair.split("=") for pair in q.split(";"))
        return equativ.list_inventory(account_id, query)
    except Exception as e:
        raise HTTPException(status_code=502, detail=str(e))
