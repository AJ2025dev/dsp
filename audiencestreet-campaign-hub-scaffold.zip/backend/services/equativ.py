import os, requests
from typing import List, Dict

EQUATIV_BASE_URL = os.getenv("EQUATIV_BASE_URL", "https://api.equativ.com")
EQUATIV_API_KEY = os.getenv("EQUATIV_API_KEY", "")

def _headers():
    return {
        "Authorization": f"Bearer {EQUATIV_API_KEY}",
        "Accept": "application/json",
    }

def list_pmp_deals(account_id: str) -> List[Dict]:
    # Stub: replace with actual Equativ endpoint you use
    url = f"{EQUATIV_BASE_URL}/v1/pmp/deals?account_id={account_id}"
    r = requests.get(url, headers=_headers(), timeout=30)
    r.raise_for_status()
    return r.json()

def list_inventory(account_id: str, query: Dict = None) -> List[Dict]:
    q = ""
    if query:
        pairs = [f"{k}={v}" for k,v in query.items()]
        q = "&" + "&".join(pairs)
    url = f"{EQUATIV_BASE_URL}/v1/inventory?account_id={account_id}{q}"
    r = requests.get(url, headers=_headers(), timeout=30)
    r.raise_for_status()
    return r.json()
