import os
from typing import Dict, Any, Optional
from openai import OpenAI

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
MINIMAX_API_KEY = os.getenv("MINIMAX_API_KEY")
MINIMAX_GROUP_ID = os.getenv("MINIMAX_GROUP_ID")
LLM_MODEL = os.getenv("LLM_MODEL", "gpt-4o-mini")

def gen_text_openai(product: str, audience: str) -> Dict[str, Any]:
    if not OPENAI_API_KEY:
        return {"error": "OPENAI_API_KEY not configured"}
    client = OpenAI(api_key=OPENAI_API_KEY)
    resp = client.chat.completions.create(
        model=LLM_MODEL,
        messages=[
            {"role":"system","content":"You are a performance ad copywriter. Generate concise, high-CTR ad variants."},
            {"role":"user","content": f"Product: {product}\nAudience: {audience}\nNeed 5 headlines and 5 descriptions."}
        ],
        max_tokens=400,
        temperature=0.7,
    )
    return {"provider":"openai","text": resp.choices[0].message.content}

def gen_text_minimax(product: str, audience: str) -> Dict[str, Any]:
    if not MINIMAX_API_KEY:
        return {"error": "MINIMAX_API_KEY not configured"}
    # Minimal HTTP example (replace with official SDK if available)
    import requests, json
    url = "https://api.minimax.chat/v1/text/chatcompletion"  # placeholder; adjust to your endpoint
    headers = {"Authorization": f"Bearer {MINIMAX_API_KEY}", "Content-Type": "application/json"}
    payload = {
        "group_id": MINIMAX_GROUP_ID,
        "model": "abab6.5-chat",  # placeholder model
        "messages": [
            {"role":"system","content":"You are a performance ad copywriter. Generate concise, high-CTR ad variants."},
            {"role":"user","content": f"Product: {product}\nAudience: {audience}\nNeed 5 headlines and 5 descriptions."}
        ]
    }
    r = requests.post(url, headers=headers, json=payload, timeout=30)
    if r.status_code != 200:
        return {"provider":"minimax","error": r.text}
    data = r.json()
    # shape depends on actual API; keep raw for now
    return {"provider":"minimax","raw": data}
